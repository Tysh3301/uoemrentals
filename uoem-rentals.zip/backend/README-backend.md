# Backend

1. Copy `.env.example` to `.env` and set `JWT_SECRET`.
2. `npm install` then `node server.js`.
3. API endpoints:
   - POST /api/auth/register { name, email, password }
   - POST /api/auth/login { email, password }
   - GET /api/rentals (protected)
   - POST /api/rentals (protected, form-data: image file + fields)
