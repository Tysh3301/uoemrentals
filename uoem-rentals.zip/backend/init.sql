CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rentals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  price_kes INTEGER NOT NULL,
  location TEXT,
  image_path TEXT
);

INSERT OR IGNORE INTO rentals (id, title, description, price_kes, location, image_path) VALUES
(1, 'Shared House near UoEm (Male/Female)', 'Shared rooms, utilities included, walking distance to campus', 4500, 'Kitikine Area, Embu', '/uploads/sample1.jpg'),
(2, 'Single Room (Self-contained)', 'Private room with own bathroom and kitchen access', 7000, 'Riandara, Embu', '/uploads/sample2.jpg'),
(3, '2-Bedroom House (split between 2)', 'Kitchen + living room, safe neighborhood', 6000, 'Town Centre, Embu', '/uploads/sample3.jpg');
