const Database = require('better-sqlite3');
const { DATABASE_FILE } = process.env;
const db = new Database(DATABASE_FILE || './rentals.db');
module.exports = db;
