require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const db = require('./db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');

const app = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me';

app.use(cors());
app.use(express.json());

const UPLOAD_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);
app.use('/uploads', express.static(UPLOAD_DIR));

const initSql = fs.readFileSync(path.join(__dirname, 'init.sql'), 'utf8');
initSql.split(';').forEach(s => {
  if (s.trim()) {
    try { db.prepare(s).run(); } catch(e){}
  }
});

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}${ext}`);
  }
});
const upload = multer({ storage });

app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ message: 'Missing fields' });
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) return res.status(409).json({ message: 'Email already used' });
  const hashed = await bcrypt.hash(password, 10);
  const info = db.prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)').run(name, email, hashed);
  const user = { id: info.lastInsertRowid, name, email };
  const token = jwt.sign(user, JWT_SECRET);
  res.json({ user, token });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  const row = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!row) return res.status(401).json({ message: 'Invalid credentials' });
  const match = await bcrypt.compare(password, row.password);
  if (!match) return res.status(401).json({ message: 'Invalid credentials' });
  const user = { id: row.id, name: row.name, email: row.email };
  const token = jwt.sign(user, JWT_SECRET);
  res.json({ user, token });
});

function authMiddleware(req, res, next) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ message: 'Missing auth header' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}

app.get('/api/rentals', authMiddleware, (req, res) => {
  const rentals = db.prepare('SELECT * FROM rentals').all();
  res.json(rentals);
});

app.post('/api/rentals', authMiddleware, upload.single('image'), (req, res) => {
  const { title, description, price_kes, location } = req.body;
  const image_path = req.file ? `/uploads/${req.file.filename}` : null;
  const info = db.prepare('INSERT INTO rentals (title, description, price_kes, location, image_path) VALUES (?, ?, ?, ?, ?)')
    .run(title, description, Number(price_kes || 0), location, image_path);
  const rental = db.prepare('SELECT * FROM rentals WHERE id = ?').get(info.lastInsertRowid);
  res.json(rental);
});

app.get('/api/rentals/:id', authMiddleware, (req, res) => {
  const rental = db.prepare('SELECT * FROM rentals WHERE id = ?').get(req.params.id);
  if (!rental) return res.status(404).json({ message: 'Not found' });
  res.json(rental);
});

app.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
