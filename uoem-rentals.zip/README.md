# UoEm Student Rentals

A simple student rentals website for University of Embu (UoEm) students.

## Quick start

1. Backend:
   - cd backend
   - npm install
   - copy .env.example to .env and set JWT_SECRET
   - node server.js

2. Frontend:
   - cd frontend
   - npm install
   - npm run dev

Backend default: http://localhost:4000
Frontend default: http://localhost:5173
