# Frontend

1. `npm install` then `npm run dev` (requires Node and npm)
2. The app expects the backend on `http://localhost:4000`. Change `src/api.js` base URL if needed.
