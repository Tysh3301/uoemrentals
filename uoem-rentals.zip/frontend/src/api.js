const API = (base = 'http://localhost:4000') => ({
  register: (body) => fetch(`${base}/api/auth/register`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body)
  }).then(r=>r.json()),
  login: (body) => fetch(`${base}/api/auth/login`, {
    method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(body)
  }).then(r=>r.json()),
  getRentals: (token) => fetch(`${base}/api/rentals`, { headers: { Authorization: `Bearer ${token}` } }).then(r=>r.json()),
  createRental: (token, formData) => fetch(`${base}/api/rentals`, { method:'POST', headers:{ Authorization:`Bearer ${token}` }, body: formData }).then(r=>r.json())
});

export default API();
