import React, { useState } from 'react'
import API from '../api'

export default function Login({ onAuth }){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [err,setErr]=useState('')
  async function submit(e){
    e.preventDefault(); setErr('')
    try{
      const res = await API.login({ email, password })
      if(res.token) onAuth(res)
      else setErr(res.message || 'Login failed')
    }catch(err){ setErr('Error') }
  }
  return (
    <form className="card" onSubmit={submit}>
      <h3>Login</h3>
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" type="email" required />
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" required />
      <button type="submit">Sign in</button>
      {err && <div style={{color:'red'}}>{err}</div>}
    </form>
  )
}
