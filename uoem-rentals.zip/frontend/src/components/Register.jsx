import React, { useState } from 'react'
import API from '../api'

export default function Register({ onAuth }){
  const [name,setName]=useState('')
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [err,setErr]=useState('')
  async function submit(e){
    e.preventDefault(); setErr('')
    try{
      const res = await API.register({ name, email, password })
      if(res.token) onAuth(res)
      else setErr(res.message || 'Registration failed')
    }catch(err){ setErr('Error') }
  }
  return (
    <form className="card" onSubmit={submit}>
      <h3>Register</h3>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" required />
      <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" type="email" required />
      <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" type="password" required />
      <button type="submit">Sign up</button>
      {err && <div style={{color:'red'}}>{err}</div>}
    </form>
  )
}
