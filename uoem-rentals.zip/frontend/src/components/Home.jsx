import React, { useEffect, useState } from 'react'
import API from '../api'
import RentalCard from './RentalCard'

export default function Home({ token, user, onLogout }){
  const [rentals, setRentals] = useState([])
  const [err, setErr] = useState('')
  const [form, setForm] = useState({ title:'', description:'', price_kes:'', location:'' })
  const [file, setFile] = useState(null)

  useEffect(()=>{ load() }, [])
  async function load(){
    try{ const rs = await API.getRentals(token); setRentals(rs) }catch(e){ setErr('Failed to load') }
  }

  async function submit(e){
    e.preventDefault()
    const fd = new FormData();
    fd.append('title', form.title); fd.append('description', form.description);
    fd.append('price_kes', form.price_kes); fd.append('location', form.location);
    if(file) fd.append('image', file);
    const res = await API.createRental(token, fd)
    setRentals(prev=>[res, ...prev])
    setForm({ title:'', description:'', price_kes:'', location:'' }); setFile(null)
  }

  return (
    <div>
      <div className="header">
        <h2>Welcome, {user.name} — Affordable rentals for UoEm students</h2>
        <div>
          <button onClick={onLogout}>Logout</button>
        </div>
      </div>

      <section style={{marginTop:12}}>
        <h3>Post a rental (for landlords / student hosts)</h3>
        <form className="card" onSubmit={submit} style={{maxWidth:600}}>
          <input placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} required />
          <textarea placeholder="Description" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
          <input placeholder="Price (KES)" value={form.price_kes} onChange={e=>setForm({...form, price_kes:e.target.value})} required />
          <input placeholder="Location" value={form.location} onChange={e=>setForm({...form, location:e.target.value})} />
          <input type="file" onChange={e=>setFile(e.target.files[0])} />
          <button type="submit">Create rental</button>
        </form>
      </section>

      <section style={{marginTop:20}}>
        <h3>Available rentals (prices in KES)</h3>
        {err && <div style={{color:'red'}}>{err}</div>}
        <div className="rentals-grid">
          {rentals.map(r => <RentalCard key={r.id} r={r} />)}
        </div>
      </section>
    </div>
  )
}
