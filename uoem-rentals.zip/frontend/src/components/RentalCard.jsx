import React from 'react'
export default function RentalCard({ r }){
  return (
    <div className="card">
      {r.image_path ? <img className="rental-img" src={`http://localhost:4000${r.image_path}`} alt={r.title} /> : <div style={{height:160, background:'#ddd', borderRadius:6}} />}
      <h4>{r.title}</h4>
      <div><strong>KES {r.price_kes.toLocaleString()}</strong></div>
      <div style={{fontSize:12, color:'#555'}}>{r.location}</div>
      <p style={{fontSize:13}}>{r.description}</p>
    </div>
  )
}
