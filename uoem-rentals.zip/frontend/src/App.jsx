import React, { useState, useEffect } from 'react'
import Register from './components/Register'
import Login from './components/Login'
import Home from './components/Home'

export default function App(){
  const [token, setToken] = useState(localStorage.getItem('token'))
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')||'null'))

  useEffect(()=>{
    if(token) localStorage.setItem('token', token)
    else localStorage.removeItem('token')
  }, [token])

  useEffect(()=>{
    if(user) localStorage.setItem('user', JSON.stringify(user))
    else localStorage.removeItem('user')
  }, [user])

  if(!token) return (
    <div className="auth-wrap">
      <h1>UoEm Student Rentals</h1>
      <div className="auth-grid">
        <Register onAuth={({user, token})=>{ setUser(user); setToken(token)}} />
        <Login onAuth={({user, token})=>{ setUser(user); setToken(token)}} />
      </div>
    </div>
  )

  return <Home token={token} user={user} onLogout={()=>{ setToken(null); setUser(null); }} />
}
